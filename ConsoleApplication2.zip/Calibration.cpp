#include "Calibration.h"
Calibration::Calibration() :
	max_iterations_(200),
	fitness_epsilon_(1e-4),
	HE(Eigen::Matrix4d::Identity()),
	norm_error_(1e+99),
	eyeinhand_(true)
{

}
void printProgressBar(int progress, int total, int barWidth, std::string add="")
{
	float percentage = (float)progress / total;
	int filledLength = barWidth * percentage;

	printf("\r[");
	for (int i = 0; i < barWidth; i++) {
		if (i < filledLength) {
			printf("#");
		}
		else {
			printf("-");
		}
	}
	printf("] %.1f%% %s", percentage * 100, add.c_str());

	fflush(stdout);
}
/*
* ��˹ţ�ٷ�
*/
void Calibration::GNcalculation(std::vector<Eigen::Vector3d>& p, std::vector<Eigen::Vector3d>& q, std::vector<int> idx, std::vector<Eigen::Matrix3d>& R, std::vector<Eigen::Vector3d>& t, int sum, Eigen::Matrix3d HER, Eigen::Vector3d HEt, Sophus::Vector6d& delta)
{
	int size = idx.size();
	Sophus::Matrix6d H = Sophus::Matrix6d::Zero();	//Hessian Matrix����ɭ����
	Sophus::Vector6d b = Sophus::Vector6d::Zero();	//bias��ƫ��
	Eigen::Vector3d residual;						//residual�����
	Eigen::Matrix<double, 3, 6> Jacobian;			//Jacobian Matrix���ſɱȾ���
	for (int i = 0; i < sum; i++)					//�������е�
	{
		for (int j = 0; j < size - 1; j++)			//�����ڵڼ�������
		{
			if (i < idx[j])
			{
				residual = R[j] * HER * p[i] + R[j] * HEt + t[j] - R[j + 1] * HER * q[i] - R[j + 1] * HEt - t[j + 1];
				Eigen::Vector3d temp1 = HER * p[i];
				Eigen::Vector3d temp2 = HER * q[i];
				Eigen::Matrix3d temp1hat = Sophus::SO3d::hat(temp1);
				Eigen::Matrix3d temp2hat = Sophus::SO3d::hat(temp2);
				//temp1hat << 0, -temp1(2), temp1(1), temp1(2), 0, -temp1(0), -temp1(1), temp1(0), 0;
				//temp2hat << 0, -temp2(2), temp2(1), temp2(2), 0, -temp2(0), -temp2(1), temp2(0), 0;
				Jacobian << -R[j] * temp1hat + R[j + 1] * temp2hat, R[j] - R[j + 1];
				break;
			}
		}
		H = H + Jacobian.transpose() * Jacobian;
		b = b - Jacobian.transpose() * residual;
	}
	delta = H.inverse() * b;
}
void Calibration::setEyeInHand(bool eyeinhand) { eyeinhand_ = eyeinhand;}
bool Calibration::getEyeInHand() { return eyeinhand_; }
void Calibration::setEuclideanFitnessEpsilon(double epsilon) { fitness_epsilon_ = epsilon; }
double Calibration::getEuclideanFitnessEpsilon() { return (fitness_epsilon_); }
void Calibration::setMaximumIterations(int nr_iterations) { max_iterations_ = nr_iterations; }
int Calibration::getMaximumIterations() { return (max_iterations_); }
void Calibration::setInputData(VectorPoseAndCloud data) { data_ = data; }
Eigen::Matrix4d Calibration::getTransformationMatrix() { return HE; }
bool Calibration::handEyeCalibration3D()
{
	int size = data_.size();					//�������ݴ�С
	std::vector<Sophus::SE3d> T_A;				//�任����
	std::vector<Eigen::Matrix3d> R;				//��ת����
	std::vector<Eigen::Vector3d> t;				//ƽ�ƾ���
	VectorCloud PTRcloud;			//ԭʼ����
	VectorCloud PTRcloudT;			//ת�����ԭʼ����
	VectorCloud PTRcloudsub;		//�²�����ĵ���
	VectorCloud PTRcloudsubT;		//ת������²�������
	float sampleRatio = 0.1;
	pcl::RandomSample<pcl::PointXYZ> rs;
	for (int i = 0; i < size; i++)
	{
		PTRcloud.push_back(data_[i].second);
		PTRcloudT.push_back(pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>()));
		PTRcloudsub.push_back(pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>()));
		PTRcloudsubT.push_back(pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>()));
		if (eyeinhand_) {
			T_A.push_back(data_[i].first);
			R.push_back(T_A[i].matrix().block(0, 0, 3, 3));
			t.push_back(T_A[i].matrix().block(0, 3, 3, 1));
		}
		else {
			T_A.push_back(data_[i].first.inverse());
			R.push_back(T_A[i].matrix().block(0, 0, 3, 3).inverse());
			t.push_back(-T_A[i].matrix().block(0, 0, 3, 3).inverse() * T_A[i].matrix().block(0, 3, 3, 1));
		}
		rs.setInputCloud(PTRcloud[i]);
		rs.setSample(ceil(PTRcloud[i]->size() * sampleRatio));
		rs.filter(*PTRcloudsub[i]);
	}
	int CorresNum = 0;
	int counter = 0;
	double trimRatio = 0.9;
	//double trimRatio = 0.5;
	double SquareDistSum = 0.0;
	double Err = 0;
	double ErrPrev = 0;
	double ratio = 0;
	double distanceThresh = 0;
	Eigen::Matrix3d HER = HE.block(0, 0, 3, 3);
	Eigen::Vector3d HEt = HE.block(0, 3, 3, 1);
	Eigen::Matrix<double, 6, 1> para;
	int m = 1;
	Eigen::Matrix<double, 6, Eigen::Dynamic> u(6, 0);
	Eigen::Matrix<double, 6, Eigen::Dynamic> g(6, 0);
	Eigen::Matrix<double, 6, Eigen::Dynamic> f(6, 0);
	Sophus::Vector6d u_k;
	Sophus::Vector6d u_next;
	Sophus::Vector6d u_0;
	
	u_0.head(3) = Sophus::SO3d(HER).log().matrix();
	u_0.tail(3) = HEt;
	u.conservativeResize(u.rows(), u.cols() + 1);
	u.col(0) = u_0;
	while (true)
	{
		printProgressBar(counter, max_iterations_, 50 , std::to_string(Err));
		if (++counter > max_iterations_)
		{
			std::cerr << "��������������" << std::endl;
			return false;
		}
		CorresNum = 0;
		SquareDistSum = 0;
		para << 0, 0, 0, HEt(0), HEt(1), HEt(2);
		std::vector<int> pointIdx(1);
		std::vector<float> pointDistance(1);
		std::vector<float> distances;
		pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
		for (int i = 0; i < size; i++)
		{
			pcl::transformPointCloud(*PTRcloudsub[i], *PTRcloudsubT[i], (T_A[i].matrix() * HE).cast<float>());
		}
		for (int t = 0; t < size - 1; t++)
		{
			if (PTRcloudsub[t]->size() < PTRcloudsub[t + 1]->size())
			{
				kdtree.setInputCloud(PTRcloudsubT[t + 1]);
				for (size_t i = 0; i < PTRcloudsubT[t]->points.size(); ++i)
				{
					kdtree.nearestKSearch(PTRcloudsubT[t]->points[i], 1, pointIdx, pointDistance);
					distances.push_back(pointDistance[0]);
				}
			}
			else
			{
				kdtree.setInputCloud(PTRcloudsubT[t]);
				for (size_t i = 0; i < PTRcloudsubT[t + 1]->points.size(); ++i)
				{
					kdtree.nearestKSearch(PTRcloudsubT[t + 1]->points[i], 1, pointIdx, pointDistance);
					distances.push_back(pointDistance[0]);
				}
			}
		}
		std::sort(distances.begin(), distances.end());
		distanceThresh = distances[ceil(distances.size() * trimRatio)];
		for (int i = 0; i < size; i++)
		{
			pcl::transformPointCloud(*PTRcloud[i], *PTRcloudT[i], (T_A[i].matrix() * HE).cast<float>());
		}
		std::vector<Eigen::Vector3d> p, q;
		std::vector<int> idx;
		for (int t = 0; t < size - 1; t++)
		{
			if (PTRcloud[t]->size() < PTRcloud[t + 1]->size())
			{
				kdtree.setInputCloud(PTRcloudT[t + 1]);
				for (size_t i = 0; i < PTRcloudT[t]->points.size(); ++i)
				{
					kdtree.nearestKSearch(PTRcloudT[t]->points[i], 1, pointIdx, pointDistance);
					if (pointDistance[0] < distanceThresh)
					{
						p.push_back(PTRcloud[t]->points[i].getVector3fMap().cast<double>());
						q.push_back(PTRcloud[t + 1]->points[pointIdx[0]].getVector3fMap().cast<double>());
						CorresNum = CorresNum + 1;
						SquareDistSum = SquareDistSum + pointDistance[0];
					}
				}
				idx.push_back(CorresNum);
			}
			else
			{
				kdtree.setInputCloud(PTRcloudT[t]);
				for (size_t i = 0; i < PTRcloudT[t + 1]->points.size(); ++i)
				{
					kdtree.nearestKSearch(PTRcloudT[t + 1]->points[i], 1, pointIdx, pointDistance);
					if (pointDistance[0] < distanceThresh)
					{
						p.push_back(PTRcloud[t]->points[pointIdx[0]].getVector3fMap().cast<double>());
						q.push_back(PTRcloud[t + 1]->points[i].getVector3fMap().cast<double>());
						CorresNum = CorresNum + 1;
						SquareDistSum = SquareDistSum + pointDistance[0];
					}
				}
				idx.push_back(CorresNum);
			}
		}
		Err = SquareDistSum / CorresNum;
		if (counter == 1) 
		{
			Sophus::Vector6d delta;
			GNcalculation(p, q, idx, R, t, CorresNum, HER, HEt, delta);
			para = para + delta;
			HER = Sophus::SO3d::exp(para.head(3)).matrix() * HER;
			HEt = para.tail(3);
			HE.block(0, 0, 3, 3) = HER;
			HE.block(0, 3, 3, 1) = HEt;
			Sophus::Vector6d u_1;
			u_1.head(3) = Sophus::SO3d(HER).log().matrix();
			u_1.tail(3) = HEt;
			u.conservativeResize(u.rows(), u.cols() + 1);
			u.col(1) = u_1;
			g.conservativeResize(g.rows(), g.cols() + 1);
			g.col(0) = u_1;
			f.conservativeResize(f.rows(), f.cols() + 1);
			f.col(0) = u_1 - u_0;
			u_next = u_1;
			u_k = u_1;
			m = m + 1;
			ErrPrev = Err;
		}
		else
		{
			ratio = Err / ErrPrev;
			if (ratio > 103)
			{
				u.col(u.cols() - 1) = g.col(g.cols() - 1);
				HER = Sophus::SO3d::exp(u.col(u.cols() - 1).head(3)).matrix();
				HEt = u.col(u.cols() - 1).tail(3);
				HE.block(0, 0, 3, 3) = HER;
				HE.block(0, 3, 3, 1) = HEt;
				u_k = u.col(u.cols() - 1);
				m = 2;
				ErrPrev = 100;
			}
			else
			{
				Sophus::Vector6d delta;
				GNcalculation(p, q, idx, R, t, CorresNum, HER, HEt, delta);
				para = para + delta;
				HER = Sophus::SO3d::exp(para.head(3)).matrix() * HER;
				HEt = para.tail(3);
				Sophus::Vector6d g_k;
				g_k.head(3) = Sophus::SO3d(HER).log().matrix();
				g_k.tail(3) = HEt;
				g.conservativeResize(g.rows(), g.cols() + 1);
				g.col(g.cols() - 1) = g_k;
				Sophus::Vector6d f_k = g_k - u_k;
				ErrPrev = Err;
				if (f_k.norm() < fitness_epsilon_)
				{
					norm_error_ = f_k.norm();
					return true;
				}
				f.conservativeResize(f.rows(), f.cols() + 1);
				f.col(f.cols() - 1) = f_k;
				Eigen::Matrix<double, 6, Eigen::Dynamic> f_recent = f.rightCols(std::min(m, 5));
				Eigen::Matrix<double, 6, Eigen::Dynamic> A = f_recent.leftCols(f_recent.cols() - 1);
				A *= -1;
				A += f_recent.rightCols(1) * Eigen::Matrix<double, Eigen::Dynamic, 1>::Constant(f_recent.cols() - 1, 1).transpose();
				Eigen::Matrix<double, Eigen::Dynamic, 1> alphas = A.colPivHouseholderQr().solve(f_recent.rightCols(1));
				alphas.conservativeResize(alphas.size() + 1);
				alphas[alphas.size() - 1] = 0;
				alphas[alphas.size() - 1] = 1 - alphas.sum();
				u_next = g.rightCols(std::min(m, 5)) * alphas;
				u.conservativeResize(u.rows(), u.cols() + 1);
				u.col(u.cols() - 1) = u_next;
				u_k = u_next;
				HER = Sophus::SO3d::exp(u_next.head(3)).matrix();
				HEt = u_next.tail(3);
				HE.block(0, 0, 3, 3) = HER;
				HE.block(0, 3, 3, 1) = HEt;
				m = m + 1;
			}
		}
	}
}
Calibration::Cloud Calibration::transformPointCloud(PairPoseAndCloud data)
{
	Calibration::Cloud cloud = std::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
	pcl::transformPointCloud(*data.second, *cloud, (data.first.matrix() * HE).cast<float>());
	return cloud;
}
