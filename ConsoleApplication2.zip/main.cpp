﻿#include <iostream>
#include "Calibration.h"

#define DLL

#ifdef DLL

#ifdef _WIN32
#define DLL_EXPORT extern "C" __declspec(dllexport)
#else
#define DLL_EXPORT extern "C"
#endif

static Calibration* calibration = new Calibration();

DLL_EXPORT void setHE(double n1, double n2, double n3, double n4, double n5, double n6) {
    Sophus::Vector6d HE;
    HE << n1, n2, n3, n4, n5, n6;
    calibration->setHE(HE);
}

DLL_EXPORT void getHE(double *n1, double *n2, double *n3, double *n4, double *n5, double *n6) {
    Sophus::Vector6d HE = calibration->getHE();
    double* n = HE.data();
    *n1 = n[0];
    *n2 = n[1];
    *n3 = n[2];
    *n4 = n[3];
    *n5 = n[4];
    *n6 = n[5];
}

DLL_EXPORT typedef struct {
    double rx, ry, rz;
    double x, y, z;
    int    cloudLen;
    double* cloud;
} CPoseAndCloud;

DLL_EXPORT typedef struct {
    int              num;
    CPoseAndCloud* items;
} CVectorPoseAndCloud;

DLL_EXPORT bool setInputData(const CVectorPoseAndCloud* data) {
    if (!data || data->num == 0) return false;
    Calibration::VectorPoseAndCloud _data;
    for (int i = 0; i < data->num; i++)
    {
        Eigen::Matrix3d R_A;
        R_A = Eigen::AngleAxisd(data->items[i].rz, Eigen::Vector3d::UnitZ()) *
            Eigen::AngleAxisd(data->items[i].ry, Eigen::Vector3d::UnitY()) *
            Eigen::AngleAxisd(data->items[i].rx, Eigen::Vector3d::UnitX());
        Eigen::Vector3d t_A(data->items[i].x, data->items[i].y, data->items[i].z);
        Eigen::Matrix4d T = Sophus::SE3d(R_A, t_A).matrix();
        Calibration::Cloud cloud(new pcl::PointCloud<pcl::PointXYZ>);
        cloud->reserve(data->items[i].cloudLen);
        double* p = data->items[i].cloud;
        for (int j = 0; j < data->items[i].cloudLen; ++j, p += 3)
        {
            cloud->push_back(pcl::PointXYZ(float(p[0]), float(p[1]), float(p[2])));
        }
        //pcl::VoxelGrid<pcl::PointXYZ> sor;
        //float leaf_size = 2.0 / 1000.0f;
        //sor.setLeafSize(leaf_size, leaf_size, leaf_size);
        //Calibration::Cloud cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);
        //sor.setInputCloud(cloud);
        //sor.filter(*cloud_filtered);
        _data.push_back(std::make_pair(Sophus::SE3d(T), cloud));
    }
    calibration->setInputData(_data);
    return calibration->handEyeCalibration3D();
}

#else

void initPointCloud(std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr>& pointCloud, int size = 9)
{
    for (int i = 0; i < size; i++)
    {
        pointCloud.push_back(pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>()));
    }
}
void readPointCloud(std::string path, std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr>& pointCloud)
{
    for (int i = 0; i < 9; i++)
    {
        pcl::io::loadPCDFile(path + "/" + std::to_string(i) + ".pcd", *pointCloud[i]);
    }
}
void readRobotPoses(std::string path, double(*_RoboPose)[6])
{
    //Read robot poses. If eye-to-hand scenario then take the inverse
    std::fstream in;
    in.open(path + "/机械臂坐标.txt", std::ios::in);//打开一个file
    if (!in.is_open()) {
        std::cout << "Can not find " << "RobotPoses.dat" << std::endl;
        system("pause");
    }
    std::string buff;
    int i = 0;//行数i
    while (getline(in, buff)) {
        std::vector<double> nums;
        // string->char *
        char* s_input = (char*)buff.c_str();
        const char* split = ",";
        // 以‘，’为分隔符拆分字符串
        char* p = strtok(s_input, split);
        double a;
        while (p != NULL) {
            // char * -> int
            a = atof(p);
            //cout << a << endl;
            nums.push_back(a);
            p = strtok(NULL, split);
        }//end while
        for (int b = 0; b < nums.size(); b++) {
            _RoboPose[i][b] = nums[b];
        }//end for
        i++;
    }//end while
    in.close();
}

int main()
{
    Calibration calibration;
    Sophus::Vector6d true_HE;
    true_HE << -88.8919, -97.9603, 163.151, -1.2149, 1.19643, -1.21602;
    calibration.setMaximumIterations(1000);
    calibration.setEuclideanFitnessEpsilon(0.001);
    calibration.setHE(true_HE);

    double RoboPose[9][6];
    std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> PTRcloud;
    std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> PTRcloudT;
    initPointCloud(PTRcloud);
    initPointCloud(PTRcloudT);
    readPointCloud(R"(C:\Users\WRW\Desktop\pc\pointcloud)", PTRcloud);
    readRobotPoses(R"(C:\Users\WRW\Desktop\pc)", RoboPose);
    // 单位是毫米
    Calibration::VectorPoseAndCloud data;
    for (int i = 0; i < PTRcloud.size(); i++)
    {
        for (int j = 0; j < PTRcloud[i]->points.size(); j++)
        {
            PTRcloud[i]->points[j].x = PTRcloud[i]->points[j].x * 1000.0;
            PTRcloud[i]->points[j].y = PTRcloud[i]->points[j].y * 1000.0;
            PTRcloud[i]->points[j].z = PTRcloud[i]->points[j].z * 1000.0;
        }

        Eigen::Matrix3d R_A;
        R_A = Eigen::AngleAxisd(RoboPose[i][2], Eigen::Vector3d::UnitZ()) *
            Eigen::AngleAxisd(RoboPose[i][1], Eigen::Vector3d::UnitY()) *
            Eigen::AngleAxisd(RoboPose[i][0], Eigen::Vector3d::UnitX());
        Eigen::Vector3d t_A(RoboPose[i][3], RoboPose[i][4], RoboPose[i][5]);
        Eigen::Matrix4d T = Sophus::SE3d(R_A, t_A).matrix();
        data.push_back(std::make_pair(Sophus::SE3d(T), PTRcloud[i]));
    }

    calibration.setInputData(data);
    std::cout << (calibration.handEyeCalibration3D() ? "OK" : "NG") << std::endl;
    std::cout << calibration.HE << std::endl;


    for (int i = 0; i < data.size(); i++)
    {
        PTRcloudT[i] = calibration.transformPointCloud(data[i]);
    }

    pcl::PointCloud<pcl::PointXYZ>::Ptr temp = std::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
    for (int i = 0; i < PTRcloudT.size(); i++)
    {
        *temp += *PTRcloudT[i];
    }

    pcl::visualization::PCLVisualizer::Ptr viewer(new pcl::visualization::PCLVisualizer("3D Viewer"));
    viewer->addPointCloud<pcl::PointXYZ>(temp, "sample cloud");
    while (!viewer->wasStopped())
    {
        viewer->spinOnce(100);
    }
    pcl::io::savePCDFileASCII(R"(C:\Users\WRW\Desktop\pc\pointcloud_merge\merge.pcd)", *temp);
}

#endif
