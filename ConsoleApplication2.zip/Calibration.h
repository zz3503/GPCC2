/*
* @misc{Xing2023-RegHEC, 
*	title={RegHEC: Hand-Eye Calibration via Simultaneous Multi-view Point Clouds Registration of Arbitrary Object},
*	author={Shiyu Xing and Fengshui Jing and Min Tan},
*	year={2023},
*	eprint={2304.14092},
*	archivePrefix={arXiv},
*	primaryClass={cs.CV}
* }
*/
#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include <pcl/common/transforms.h>  
#include <pcl/io/pcd_io.h> 
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/filters/random_sample.h>
#include <pcl/registration/icp.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <sophus/types.hpp>
#include <sophus/so3.hpp>
#include <sophus/se3.hpp>
class Calibration
{
public:
	typedef pcl::PointCloud<pcl::PointXYZ>::Ptr Cloud;
	typedef std::vector<Cloud> VectorCloud;
	typedef std::pair<Sophus::SE3d, Cloud> PairPoseAndCloud;
	typedef std::vector<PairPoseAndCloud> VectorPoseAndCloud;
public:
	Calibration();
	void setEyeInHand(bool eyeinhand);
	bool getEyeInHand();
	void setEuclideanFitnessEpsilon(double epsilon);
	double getEuclideanFitnessEpsilon();
	void setMaximumIterations(int nr_iterations);
	int getMaximumIterations();
	void setInputData(VectorPoseAndCloud data);
	bool handEyeCalibration3D();
	Cloud transformPointCloud(PairPoseAndCloud data);
	Eigen::Matrix4d getTransformationMatrix();
	void setHE(Sophus::Vector6d _HE)
	{
		HE = Sophus::SE3d::exp(_HE).matrix();
		//HE.block(0, 0, 3, 3) = Sophus::SO3d::exp(_HE.head(3)).matrix();
		//HE.block(0, 3, 3, 1) = _HE.tail(3);
	}
	Sophus::Vector6d getHE()
	{
		Sophus::Vector6d _HE = Sophus::SE3d(HE).log().matrix();
		//_HE.head(3) = Sophus::SO3d(HE.block(0, 0, 3, 3)).log().matrix();
		//_HE.tail(3) = HE.block(0, 3, 3, 1);
		return _HE;
	}
public:
	int max_iterations_;
	double fitness_epsilon_;
	double norm_error_;
	VectorPoseAndCloud data_;
	Eigen::Matrix4d HE;
	bool eyeinhand_;
private:
	void GNcalculation(std::vector<Eigen::Vector3d>& p, std::vector<Eigen::Vector3d>& q, std::vector<int> idx, std::vector<Eigen::Matrix3d>& R, std::vector<Eigen::Vector3d>& t, int sum, Eigen::Matrix3d HER, Eigen::Vector3d HEt, Sophus::Vector6d& delta);
};
